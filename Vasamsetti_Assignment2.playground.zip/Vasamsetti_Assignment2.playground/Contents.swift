// author : s525251

// Vehicle class 
class Vehicle {
    var speed:Double = 0  // speed a stored property (units miles per hour)
    // speedInKph - a computed property(speed in kph)
    var speedInKph:Double {
        get {
            return speed
        }
        
        set {
            // converts miles/hour into kph and assigns to speed variable
            speed = newValue*1.6
        }
    }
    
    // returns true if the speed is less than the argument
    func drivingSafely(maxSpeed:Double) -> Bool {
        
        if speed < maxSpeed {
            
            return true
        }
        else {
            
            return false
        }
        
    }
    
    // returns a String, "Speed:speed", replacing speed with the value
    func description() -> String {
        
        return "Speed: \(speed)"
    }
    
    // initializes the stored property 'speed' to the value of the parameter
    init(speed:Double) {
        
        self.speed = speed
    }
    
    // convenience initializer to initialize the speed to 0.0
    convenience init() {
        
        self.init(speed:0.0)
    }
}

// a subclass of Vehicle

class Car:Vehicle {
    
    private var _numPassengers:Int = 0 // private stored property that underlies numPassengers
    var deerHornInstalled:Bool = false  // a Bool stored property
    let MAX_NUM_PASSENGERS:Int = 6
    var numPassengers:Int {
        
        get {
            
            return _numPassengers
        }
        
        set {
            
            if newValue >= 0 && newValue <= MAX_NUM_PASSENGERS {
                
                _numPassengers = newValue
                
            }
            else {
                
                
                _numPassengers = 0
            }
            
        }
    }
    
    // returns a String, "Num Passengers:passengers,Speed:speed"
    override func description() -> String {
        
        return "Num Passengers: \(numPassengers), \(super.description())"
    }
    
    /* initializes the _numPassengers,deerHornInstalled with appropriate parameters and to intialize the stored property 'speed' Vehicle init(speed) 
        will be called as a last statement */
    init(speed:Double,numPassengers:Int,deerHornInstalled:Bool) {
        
        self._numPassengers = numPassengers
        self.deerHornInstalled = deerHornInstalled

        // Calling Vehicle init(speed)
        super.init(speed:speed)
        
    }
    
    // convenience initializer to initialize the speed,numPassengers,deerHornInstalled with 0.0,0,false respectively
    convenience init() {
        
        self.init(speed:0.0,numPassengers:0,deerHornInstalled:false)
    }
}

// a subclass of Vehicle

class Truck:Vehicle {
    
    var payload:Double = 0.0   // stored property
    var companyName:String = ""  // stored property
    
    // returns a String ,"Owned by company name:companyName" replacing companyName with the value
    override func description() ->String {
        
        return "Owned by \(companyName)"
    }
    
    // initializes the payload,companyName with appropriate parameters and to initialize the 'speed' Vehicle's initializer will be called
    init(speed:Double,payload:Double,companyName:String) {
     
        self.payload = payload
        self.companyName = companyName
        super.init(speed:speed)
    }
    
    // convenience initializer initializes the speed,payload,companyName with 0.0,0,"" appropriately
    convenience init() {
        
        self.init(speed:0.0,payload:0.0,companyName:"")
    }
    
    // convenience initializer initializes the payload to 0.0,companyName to "ACME" and speed with the parameter passed
    convenience override init(speed:Double) {
        
        self.init(speed:speed,payload:0.0,companyName:"ACME")
    }
    
    // convenience initializer initializes the speed and payload to 0.0.companyName with the parameter passed to the function
    convenience init(companyName:String) {
        
        self.init(speed:0.0,payload:0.0,companyName:companyName)
    }
}

// a class to keep track of the number of Trucks and Cars

class TrafficMonitor {
    
    var speeds:[Double] = [] // stored property to track the speed of passing vehicles
    
    // records the speed of its argument in speeds
    func registerSpeed(vehicle:Vehicle) {
        
       speeds.append(vehicle.speed)
    }
    
    // clears speeds to an empty array
    func reset() {
        
        speeds.removeAll()
    }
    
    // returns the minimum speed in speeds
    func minSpeed() -> Double {
     
        var minSpeed:Double = speeds[0]
        
        for var i:Int = 0; i < speeds.count; i++ {
            
            if speeds[i] < minSpeed {
                
                minSpeed = speeds[i]
            }
        }
        
        return minSpeed
        
    }
    
    // returns the maximum speed in speeds
    func maxSpeed() ->Double {
    
        var maxSpeed:Double = 0.0
        
        for var i:Int = 0 ; i < speeds.count; i++ {
            
            if speeds[i] > maxSpeed {
                
                maxSpeed = speeds[i]
            }
        }
        return maxSpeed
        
    }
    
    // returns the median speed in speeds
    func medianSpeed() -> Double {
        
        let tempSpeeds:[Double] = speeds.sort()
       
        if speeds.count % 2 == 0 {
            
            return  (tempSpeeds[speeds.count/2] + tempSpeeds[speeds.count/2-1])/2
        }
        else {
            
            return tempSpeeds[(speeds.count)/2]
        }
        
    }
    
    /* returns a 2-line string that
        1. speeds:[speed0,speed1,...,speed n-1] // replaced with actual speeds
        2. Minimum Speed: minSpeed,Maximum Speed: maxSpeed, Median Speed: medianSpeed" 
       The values for minSpeed,maxSpeed,medianSpeed obtained by calling appropriate functions  */
    func description() -> String {
        
        return "1.speeds:\(speeds)\n2.Minimum Speed:\(minSpeed()),Maximum Speed:\(maxSpeed()),Median Speed:\(medianSpeed())"
    }
    
    // sets speeds to []
    init() {
        speeds = []
    }
}

func simulateRoadConditions() -> Void {
    
   
    let Car0 = Car(speed:50.0,numPassengers:3,deerHornInstalled:false)
    let Car1 = Car(speed:65.0,numPassengers:4,deerHornInstalled:true)
    let Car2 = Car(speed:55.0,numPassengers:2,deerHornInstalled:false)
    let Truck0 = Truck(speed:75.0,payload:1000.0,companyName:"Bearcat Haulers")
    let Truck1 = Truck(speed:67.0,payload:-500.0,companyName:"Lighter than Air transport")
    
    // traffic array with 3 Cars and 2 Trucks objects
    var traffic = [Car0,Car1,Car2,Truck0,Truck1]
    
    // print out of Car1
    print(traffic[1].description())
    
    // printout of Truck0
    print(traffic[3].description())
    
    // Create trafficMonitor object
    let trafficMonitor = TrafficMonitor()
    
    // calling registerSpeed function to register the speeds of each of the traffic Vehicles
    for vehicle in traffic {
        
        trafficMonitor.registerSpeed(vehicle)
    }
    
    // printout of trafficMonitor
    print(trafficMonitor.description())
    
    // invoking reset function
    trafficMonitor.reset()
    
    // Creation of Truck object 'Truck2' and adding Truck2 object in traffic array
   let Truck2 = Truck(speed:85.0,payload:25.0,companyName:"Don't Hit the Median While Calculating the Median")
    traffic.append(Truck2)
    
    // calling registerSpeed function to register the speeds of each of the traffic Vehicles
    for vehicle in traffic {
        
        trafficMonitor.registerSpeed(vehicle)
    }
    
  // printout of trafficMonitor
  print(trafficMonitor.description())
}

simulateRoadConditions()

