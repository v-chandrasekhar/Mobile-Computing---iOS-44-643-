//
//  ViewController.swift
//  Vasamsetti_Assignment03
//
//  Created by chandu on 2/5/16.
//  Copyright © 2016 s525251. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // this function updates the background color depending on the temperatures
    func colorForTempearture(tempCelsius:Double)->UIColor {
        
        if tempCelsius < 0 {
            title1.text = ("Be😈rcat Temp😉rature C😝nverter 🌥🌥🌥🌥🌥🌥")
            return UIColor.blueColor()
        }
        else if tempCelsius >= 0 && tempCelsius < 20  {
            title1.text = ("Be😈rcat Temp😉rature C😝nverter 🌤🌤🌤🌤🌤🌤")
            return UIColor.lightGrayColor()
        }
        else if tempCelsius >= 20 && tempCelsius < 30 {
            title1.text = ("Be😈rcat Temp😉rature C😝nverter 🌝🌝🌝🌝🌝🌝")
            return UIColor.greenColor()
        }
        else if tempCelsius >= 30 && tempCelsius < 40 {
            title1.text = ("Be😈rcat Temp😉rature C😝nverter 🌞🌞🌞🌞🌞🌞")
            return UIColor.redColor()
        }
        else{
            title1.text = ("Be😈rcat Temp😉rature C😝nverter ☀️☀️☀️☀️☀️☀️")
            return UIColor.yellowColor()
        }
    }
    
    //function to convert the temperature from celsius to fahrenheit
    func celsiusToFahrenheit(tempCelsius:Double)->Double{
        return ((tempCelsius*2)+30)
    }
    
    //function to convert the temperature from fahrenheit to Celsius
    func fahrenheitToCelsius(tempFahrenheit:Double)->Double{
        return (tempFahrenheit-30)/2
    }
    
    
    @IBOutlet weak var title1: UILabel!
    
    
    @IBOutlet weak var fahrenheit: UITextField!
    
    @IBOutlet weak var celsius: UITextField!
    
    
    @IBOutlet weak var fahrenheitWarning: UILabel!
    @IBOutlet weak var celsiusWarning: UILabel!
    
    
    //function to invoke the action when the FtoC_BTN is clicked
    @IBAction func FtoC_BTN(sender: AnyObject) {
        let f:Double? = Double(fahrenheit.text!)
        if f != nil {
            fahrenheitWarning.text = ""
            celsiusWarning.text = ""
            celsius.text = String(fahrenheitToCelsius(f!))
            view.backgroundColor = colorForTempearture(f!)
        }
        else{
            fahrenheitWarning.text = "Input is missing"
        }
    }
    
    //function to invoke the action when the CtoF_BTN is clicked
    @IBAction func CtoF_BTN(sender: AnyObject) {
        let c:Double? = Double(celsius.text!)
        if c != nil {
            celsiusWarning.text = ""
            fahrenheitWarning.text = ""
            fahrenheit.text = String(celsiusToFahrenheit(c!))
            view.backgroundColor = colorForTempearture(c!)
        }
        else{
            celsiusWarning.text = "Input is missing"
        }
    }
    
    
    

}

