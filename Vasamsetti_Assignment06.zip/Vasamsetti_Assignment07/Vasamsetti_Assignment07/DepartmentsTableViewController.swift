//
//  DepartmentsTableViewController.swift
//  Vasamsetti_Assignment07
//
//  Created by chandrasekhar vasamsetti on 3/8/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import UIKit

class DepartmentsTableViewController: UITableViewController {

    
    @IBOutlet var tableVi: UITableView!
    // declaring University stored object 'university'
    var university:University!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // instance of University is assigned to university
        university = University()
        
        // to download and parse a JSON file
        university.populateUniversity()
        NSNotificationCenter.defaultCenter().addObserver(self, selector:Selector("reloadData:"), name: "Data Delivered", object: nil)
       
        self.tableView.registerClass(UITableViewCell.classForCoder(), forCellReuseIdentifier: "department_cell")
        // Assigning
        self.navigationItem.title = "Departments"
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // void method to tell the tableView to reload data
    func reloadData(x:NSNotification) {
        
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        if university.departments != nil {
        return university.departments.count
        }
        else {
            
            return 0
        }
    }
    
    // The usual method for populating the cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("department_cell", forIndexPath: indexPath) as UITableViewCell
        
        cell.textLabel?.text = university.departments[indexPath.row].name
        return cell
        
    }
    // This method called when user selects a row
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        _ = tableView.indexPathForSelectedRow!
        if let _ = tableView.cellForRowAtIndexPath(indexPath) {
            self.performSegueWithIdentifier("Faculty", sender: self)
        }
    }
    // Determine the selected department and assign it to the department of the destination view controller
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        if segue.identifier == "Faculty" {
        
        if let destination = segue.destinationViewController as? FacultyTableViewController {
         
            let indexPath = self.tableView.indexPathForSelectedRow!
           
           destination.department = university.departments[indexPath.row]
        }
        
        }
    }
        
}

