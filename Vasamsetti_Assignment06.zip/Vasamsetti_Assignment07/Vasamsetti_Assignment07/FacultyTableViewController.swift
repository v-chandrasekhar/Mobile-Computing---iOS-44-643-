//
//  FacultyTableViewController.swift
//  Vasamsetti_Assignment07
//
//  Created by chandrasekhar vasamsetti on 3/8/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import UIKit

// FacultyTableViewController is used to display list of the faculty members in the selected department
class FacultyTableViewController: UITableViewController {
    
    // Department stored object 'department'
    var department:Department!
    
    @IBOutlet var t: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // To display department name in the navigation title of FacultyTableViewController
        self.navigationItem.title = department.name
    
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section.
        return   department.faculty.count
    }
    
    // // The usual method for populating the cell
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
       
        var cell:UITableViewCell! =  tableView.dequeueReusableCellWithIdentifier("professor_cell")
       
        if cell == nil {
            cell = UITableViewCell.init(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "professor_cell")
        }
        // assigning first name to the text label
        cell.textLabel?.text = department.faculty[indexPath.row].firstName
        
        // assigning last name to the detail Text label
        cell.detailTextLabel?.text = department.faculty[indexPath.row].lastName
       
        return cell
    }
    // This method called when user selects a row
//    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//        
//        _ = tableView.indexPathForSelectedRow!
//        if let _ = tableView.cellForRowAtIndexPath(indexPath) {
//            self.performSegueWithIdentifier("Professor", sender: self)
//        }
//
//    }
    // Determine the selected department faculty and assign it to the professor of the destination view controller
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        if segue.identifier == "Professor" {
        print("chandu")
          if let destination = segue.destinationViewController as? ProfessorInfoViewController {
         
             let indexPath = self.tableView.indexPathForSelectedRow!
             destination.professor = department.faculty[indexPath.row]
          }
        }
      }
}

