//
//  ProfessorInfoViewController.swift
//  Vasamsetti_Assignment07
//
//  Created by chandrasekhar vasamsetti on 3/10/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import UIKit

// ProfessorInfoViewController is used to display office location and office hours of the selected professor
class ProfessorInfoViewController:UIViewController {
    // label to display office location
    @IBOutlet weak var office: UILabel!
    
    // label to display office hours
    @IBOutlet weak var officeHours: UILabel!
    
    // Professor stored property
    var professor:Professor!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = professor.firstName + " " + professor.lastName
        // assigning professor office location to the office label
        office.text = "Office:" + " " + professor.office
        // assigning professor office hours to the officeHours label
        officeHours.text = "Office Hours" + " " + professor.officeHours
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
      // navigation title of the ProfessorInfoViewController
      self.navigationItem.title = professor.firstName + " " + professor.lastName
      // assigning professor office location to the office label
      office.text = "Office:" + " " + professor.office
      // assigning professor office hours to the officeHours label
      officeHours.text = "Office Hours" + " " + professor.officeHours
       print("prof")
    }
    
    
}
