//
//  ViewController.swift
//  Multilingual App
//
//  Created by chandrasekhar vasamsetti on 3/29/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputTV: UITextView!
    
    @IBOutlet weak var outputTV: UITextView!
    
    let languageCode = ["Japanese":"ja","French":"fr","Hindi":"hi"]
    var langDictionary:[Int:String] = [0:"ja", 1:"fr", 2:"hi", 3:"en"]
    
    var lang:String = "ja"
    var lang2:String = "ja-ja"
    
    @IBOutlet weak var langSegmentLBL: UISegmentedControl!
    
    @IBAction func langSegmentAC(sender: AnyObject) {
        lang2 = lang+"-"+langDictionary[sender.selectedSegmentIndex]!
        
        lang = langDictionary[sender.selectedSegmentIndex]!
       
    }
    @IBAction func translateBTN(sender: AnyObject) {
       
        
        let url = NSURL(string: "https://translate.yandex.net/api/v1.5/tr.json/translate?key=trnsl.1.1.20160307T213950Z.3c5c87c3e34aaaae.bfe9021dfa7e4b7e1ef4826c52e2e8781c8a1813&text=\(inputTV.text!.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLPathAllowedCharacterSet())!)&lang=\(lang2)")
                let session = NSURLSession.sharedSession()
        
        session.dataTaskWithURL(url!, completionHandler: processResults).resume()
     }
    func processResults(data:NSData?,response:NSURLResponse?,error:NSError?)->Void {
        var people:AnyObject!
        do {
            try people = NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.AllowFragments)
            let textop = people["text"]!![0]!
            
            print(textop)
            dispatch_async(dispatch_get_main_queue(), {
                
                self.outputTV.text! = "\(textop)"
            })
            dispatch_async(dispatch_get_main_queue()){
                NSNotificationCenter.defaultCenter().postNotificationName("Data Delivered", object: nil)
            }
        }catch {
            
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        inputTV.editable = true
        outputTV.editable = false
    NSNotificationCenter.defaultCenter().addObserver(self, selector:"process", name:"Data delivered", object: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

