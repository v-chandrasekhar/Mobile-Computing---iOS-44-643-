//
//  SettingsViewController.swift
//  Math
//
//  Created by chandrasekhar vasamsetti on 2/14/16.
//  Copyright © 2016 s525251. All rights reserved.
//

import Foundation
import UIKit

class SettingsViewController : UIViewController, UITextFieldDelegate {
    
    var mathTeacher:MathTeacher?
        
    @IBOutlet weak var maximumProblemSizeTF: UITextField!
    
    
    @IBOutlet weak var plusBTN: UIButton!
    
    @IBOutlet weak var minusBTN: UIButton!
    
    // plusBTN is called when user tap on plus sign
    @IBAction func plusBTN(sender: AnyObject) {
        
        mathTeacher!.operation = .Plus
        plusBTN.backgroundColor = UIColor.greenColor()
        minusBTN.backgroundColor = UIColor.whiteColor()
        
    }
    
    // minusBTN is called when user tap on minus sign
    @IBAction func minusBTN(sender: AnyObject) {
    
        mathTeacher!.operation = .Minus
        plusBTN.backgroundColor = UIColor.whiteColor()
        minusBTN.backgroundColor = UIColor.greenColor()
    
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        maximumProblemSizeTF.delegate = self
        // shared application to connect to MathTeacher
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        
        mathTeacher = appDelegate?.mathTeacher
        maximumProblemSizeTF.text = String(mathTeacher!.maximumProblemSize)
        plusBTN.backgroundColor = UIColor.greenColor()
        
        
    }
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        var maximumValue:Int?
        let receivedAnswer = maximumProblemSizeTF.text
        maximumValue = Int(receivedAnswer!)
        
        // checks the value entered in the textfield
        if maximumValue != nil && maximumValue > 0
        {
            
            mathTeacher!.maximumProblemSize = maximumValue!
            
            mathTeacher!.makeNewProblem()
        }
        else
        {
            
            maximumProblemSizeTF.text = String(9)
            mathTeacher?.maximumProblemSize = 9
            mathTeacher!.makeNewProblem()
        }
        textField.resignFirstResponder()
        return true
    }
}