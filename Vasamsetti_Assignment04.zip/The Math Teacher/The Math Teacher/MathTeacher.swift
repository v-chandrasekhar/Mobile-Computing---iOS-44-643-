//
//  MathTeacher.swift
//  The Math Teacher
//
//  Created by chandrasekhar vasamsetti on 2/14/16.
//  Copyright © 2016 s525251. All rights reserved.
//

import Foundation

// enum operationType
enum operationType : String {
        case Plus = "+", Minus = "-"
    }
class MathTeacher {
    
    // declaring operand1 and operand2 with value 1
    var operand1:Int = 1
    var operand2:Int = 1
    
    
    
    var operation:operationType = .Plus
    
    
    var history:String = ""
    var maximumProblemSize:Int = 9
    
    // to create a new problem by using random function
    func makeNewProblem(){
        
        operand1 = random() % maximumProblemSize + 1
        operand2 = random() % maximumProblemSize + 1
        
    }
    
    // to check the answer is correct or not
    func answerIsCorrect(answer:Int) -> Bool {
        
        var totalValue:Int = 0
        
        switch operation {
            
        case .Plus : totalValue = operand1 + operand2
            
        case .Minus : totalValue = operand1 - operand2
            
        }
        // appends history each time when the answer is right or wrong
        history = history + "\(operand1) \(operation.rawValue) \(operand2) = \(answer); \(totalValue == answer) \n"
        
        
        if totalValue == answer {
            
            return true
        }
        else {
            
            return false
        }
        
    }
    
    
}