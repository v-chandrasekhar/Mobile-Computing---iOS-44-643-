//
//  ProblemsViewController.swift
//  The Math Teacher
//
//  Created by chandrasekhar vasamsetti on 2/14/16.
//  Copyright © 2016 s525251. All rights reserved.
//

import Foundation
import UIKit

class ProblemsViewController : UIViewController,UITextFieldDelegate {
    
    var mathTeacher:MathTeacher!
    
    
    override func viewDidLoad() {
        
        answerTF.delegate = self
        
        
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        
        mathTeacher = appDelegate!.mathTeacher
        // assign default values from the MathTeacher class through mathTeacher object.
        operand1LBL.text = String(mathTeacher.operand1)
        operand2LBL.text = String(mathTeacher.operand2)
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // operand1 label
    @IBOutlet weak var operand1LBL: UILabel!
    
    // operation label
    @IBOutlet weak var operationLBL: UILabel!
    
    // operand2 label
    @IBOutlet weak var operand2LBL: UILabel!
    
    // answerTF textfield
    @IBOutlet weak var answerTF: UITextField!
    
    // checkAnswerBTN action
    @IBAction  func checkAnswerBTN(sender: AnyObject) {
        
        var checkAnswer:Int?
        
        let enteredAnswer = answerTF.text
        

        checkAnswer = Int(enteredAnswer!)
        
        var titlePopUpText = ""
        var messagePopUpText = ""
        // assigns appropriate message to the titlePopUpText and messagePopUpText based on the value of the checkAnswer
        if checkAnswer == nil {
            
            titlePopUpText = "Invalid input😳😨"
            messagePopUpText = "Enter correct input!!!"

            
        }
        else {
            
            
            let answer = mathTeacher.answerIsCorrect(checkAnswer!)
            
            if answer == true {
                
                titlePopUpText = "Correct Answer👏😊😊"
                messagePopUpText = "Congrats!!!"
                
            }
            else {
                titlePopUpText = "Incorrect Answer☹️☹️☹️"
                messagePopUpText = "Try again👍"
                
            }
       }
         displayAlertControllerWithTitle(titlePopUpText,message:messagePopUpText)

    }
    
    // makeNewProblemBTN action
    @IBAction func makeNewProblemBTN(sender: AnyObject) {
        
        answerTF.text = ""
        mathTeacher?.makeNewProblem()
        
        operand1LBL.text = String(mathTeacher!.operand1)
        operand2LBL.text = String(mathTeacher!.operand2)
    }
    
    // This function will be called when the user press enter in the text field.
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        checkAnswerBTN(answerTF)
        textField.resignFirstResponder()
        return true
    }

    // This function show the content of operation1LBL and operation2LBL taken from MathTeacher class
    override func viewWillAppear(animated: Bool) {
        
        operationLBL.text = mathTeacher.operation.rawValue
        operand1LBL.text = String(mathTeacher.operand1)
        operand2LBL.text = String(mathTeacher.operand2)
    }
    
    // To display the appropriate title and message when checkAnswer function is called 
    func displayAlertControllerWithTitle(title:String,message:String) {
        
        let uiAlertController:UIAlertController = UIAlertController(title: title,
            message: message, preferredStyle: UIAlertControllerStyle.Alert)
        uiAlertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel,
            handler:{(action:UIAlertAction)->Void in  }))
        self.presentViewController(uiAlertController, animated: true, completion: nil)
    }
    
}
