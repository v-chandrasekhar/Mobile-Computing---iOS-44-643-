//
//  SecondViewController.swift
//  MathTeacher
//
//  Created by chandrasekhar vasamsetti on 2/14/16.
//  Copyright © 2016 s525251. All rights reserved.
//

import UIKit

class HistoryViewController: UIViewController {

    // MathTeacher class object
    var mathTeacher:MathTeacher?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let appDelegate = UIApplication.sharedApplication().delegate as? AppDelegate
        mathTeacher = appDelegate!.mathTeacher
        historyTV.text = mathTeacher?.history
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var historyTV: UITextView!
    
    override func viewWillAppear(animated: Bool) {
        //gets history variable from the MathTeacher class assign it to the historyTV
        historyTV.text = mathTeacher?.history
    }

}

