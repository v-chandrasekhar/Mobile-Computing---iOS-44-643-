//: Playground - noun: a place where people can play

// author: S525251

// program 0
func numEvens(a:[Int]) -> Int {
    
    var count:Int = 0
    
    for num in a {
        
        if num%2 == 0 {
            
            count++
        }
    }
    return count
}

print(numEvens([]))
print(numEvens([15]))
print(numEvens([15,18,22]))
print(numEvens([15,28,numEvens([15,28])]))

// program 1
func inOrder(inout a:Int,inout b:Int,inout c:Int) {
    

    var temp:Int
    
        if a>b {
            
            temp = a
            a = b
            b = temp
            
                
        }
        if b>c {
            
            temp = b
            b = c
            c = temp
        }
       if a>b {
        
        temp = a
        a = b
        b = temp
       }


}


var x:Int = 10
var y:Int = 2
var z:Int = 8
inOrder(&x,b:&y,c:&z)


//program 2

func arraySum(var a:[Int],var b:[Int]) -> [Int] {
    
    if a.count != b.count {
        
        return []
    }
    else {
        
        var c = [Int]()
        for var x:Int=0; x<a.count; x++ {
            c.append(a[x]+b[x])
        }
        return c
    }
}
var p:[Int] = [0,3,5]
var q:[Int] = [3,2,0]
print(arraySum(p,b:q))

// program 3
func findMissingInts(a:Int...){
    
    let length:Int=a.count-1
    var x:Int
    for x=a[0]; x < a[length]; x++ {
        
        if !a.contains(x) {
            
            if x != a[length]-1 {
               
                print("\(x)",terminator:",")
            }
            else {
                
                print("\(x)")
            }
            
        }
    }
}

findMissingInts(1,3,8,9,12)
findMissingInts(10,15)
findMissingInts(1,3,8,9,12)
findMissingInts(1,3,4,5,10)
findMissingInts(1,2,3,8)
