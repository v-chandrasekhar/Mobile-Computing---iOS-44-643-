//
//  RainView.swift
//  The Botanical Assignment
//
//  Created by Chandrasekhar,Vasamsetti on 3/30/16.
//  Copyright © 2016 Chandrasekhar,Vasamsetti. All rights reserved.
//

import UIKit

class RainView: UIView {

    
    var rainVC:RainViewController!
    
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        
        let numberOfRaindrops:Int = rainVC.numberOfRaindrops
        let radius:Float = rainVC.radius
        let color:UIColor = rainVC.color
        
        var xAxis:Double
        var yAxis:Double

          
        let bp:UIBezierPath = UIBezierPath()
        
        //Takes the screen size
//        let screenSize: CGRect = UIScreen.mainScreen().bounds
        let screenWidth = Int(self.frame.size.width)
        let screenHeight = Int(self.frame.size.height)
        
        //print(screenHeight)
        for var i:Int = 0; i < numberOfRaindrops; i++
        {
            xAxis = Double(random()%screenWidth)
            yAxis = Double(random()%screenHeight)
            
            bp.moveToPoint(CGPoint(x: xAxis, y: yAxis))
            bp.addArcWithCenter(CGPoint(x:xAxis , y: yAxis), radius:CGFloat(radius), startAngle: 0, endAngle: 6.28, clockwise: true)
            bp.closePath()
            
        }
        
        color.setFill()
        bp.fill()
    }
    
}
