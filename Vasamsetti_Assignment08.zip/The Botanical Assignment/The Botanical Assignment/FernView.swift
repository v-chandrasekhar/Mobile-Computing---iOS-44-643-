//
//  FernView.swift
//  The Botanical Assignment
//
//  Created by Chandrasekhar,Vasamsetti on 3/30/16.
//  Copyright © 2016 Chandrasekhar,Vasamsetti. All rights reserved.
//

import UIKit

class FernView: UIView {

    var fernMaker:FernMaker!
    
   
    override func drawRect(rect: CGRect) {
        // Drawing code
        let bp:UIBezierPath = UIBezierPath()
        var points:[CGPoint] = fernMaker.points
        var point:CGPoint
        
        for var i:Int = 0; i < points.count; i++
        {
            point = CGPoint(x: (points[i].x+6)*30, y: (points[i].y)*40 )
            
            bp.moveToPoint(point)
            bp.addArcWithCenter(point, radius:CGFloat(1), startAngle: 0, endAngle: 6.28, clockwise: true)
            bp.closePath()
        }
        
        UIColor.blueColor().setFill()
        bp.fill()
    }
    

}
