//
//  RainViewController.swift
//  The Botanical Assignment
//
//  Created by Chandrasekhar,Vasamsetti on 3/30/16.
//  Copyright © 2016 Chandrasekhar,Vasamsetti. All rights reserved.
//

import UIKit

class RainViewController: UIViewController {
    
    var color:UIColor!
    var radius:Float!
    var numberOfRaindrops:Int!
    
    
    
    @IBOutlet var rainView:RainView!
    //Prepare for segue, reference the rainVC
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
                 
      let settings = segue.destinationViewController as? SettingsViewController
      settings!.rainVC = self
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        rainView.setNeedsDisplay()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        rainView.rainVC = self
        color = UIColor.redColor()
        radius = 5
        numberOfRaindrops = 5
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
}

