//
//  FernMaker.swift
//  The Botanical Assignment
//
//  Created by Chandrasekhar,Vasamsetti on 3/30/16.
//  Copyright © 2016 Chandrasekhar,Vasamsetti. All rights reserved.
//


import UIKit
class FernMaker
{
    var points:[CGPoint] = []
    
    var globalPoint:CGPoint = CGPoint(x: 0.16, y: 0.0)
    func generateFern(numberOfPoints:Int){
        
        //Add seed
        points.append(t0(CGPoint(x: 0.6, y: 0.7)))
        
        //generate remaining points
        for i in 0...numberOfPoints-1 {
            
            let rand:Int = random()%100 + 1
            
            if rand <= 1 {
                
                points.append(t0(points[i]))
                
            }
                
            else if rand <= 86 {
                
                points.append(t1(points[i]))
                
            }
                
            else if rand <= 93 {
                
                points.append(t2(points[i]))
                
            }
                
            else {
                
                points.append(t3(points[i]))
                
            }
            
        }
        
    }
    
    func t0(point: CGPoint)->CGPoint{
        return CGPoint(x:0.16, y:0.0)
    }
    
    func t1(point: CGPoint) -> CGPoint{
        return CGPoint(x: 0.85 * point.x + 0.04 * point.y, y: -0.04 * point.x + 0.85 * point.y + 1.6)
    }
    
    func t2(point: CGPoint)->CGPoint{
        return CGPoint(x: 0.2*point.x - 0.26*point.y, y: 0.23*point.x + 0.22*point.y + 1.6)
    }
    
    func t3(point: CGPoint)->CGPoint{
        return CGPoint(x: -0.15*point.x + 0.28*point.y,y: 0.26*point.x + 0.24*point.y + 0.44)
    }
    
}