//
//  SettingsViewController.swift
//  The Botanical Assignment
//
//  Created by Chandrasekar,Vasamsetti on 3/30/16.
//  Copyright © 2016 Chandrasekhar,Vasamsetti. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var colorSegmentControl: UISegmentedControl!
    @IBOutlet weak var numOfRaindropsTF: UITextField!
    @IBOutlet weak var radiusSlider: UISlider!
    
    var rainVC:RainViewController!
    
    //Dictionary to store colors
    let colorDict:[Int:UIColor] = [0:UIColor.redColor(),1:UIColor.orangeColor(),2:UIColor.yellowColor(),3:UIColor.greenColor(),4:UIColor.blueColor(),5:UIColor.blackColor()]
    
    
    
    @IBAction func doneSettingBTN(sender: AnyObject) {
        
        //setting rainVC values
        
        rainVC.color = colorDict[colorSegmentControl.selectedSegmentIndex]
        rainVC.radius = radiusSlider.value
        
        var numberOfDrops:Int?
        
        //Number of rain drops
        let drops = numOfRaindropsTF.text
        
        numberOfDrops = Int(drops!)
        
        if numberOfDrops != nil && numberOfDrops>0
        {
            rainVC.numberOfRaindrops = numberOfDrops
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        else
        {
            displayAlertControllerWithTitle("Invalid input", message:"Default raindrops number is set to 5")
            rainVC.numberOfRaindrops = 5
            numOfRaindropsTF.text = "5"
        }

        
    }
    
    override func viewWillAppear(animated: Bool) {
        colorSegmentControl.selectedSegmentIndex = findKeyForColorValue(colorDict,color: rainVC.color)
        radiusSlider.value = rainVC.radius
    }
    
    //returns key for dictionary
    func findKeyForColorValue(dictionary:[Int:UIColor],color:UIColor)->Int
    {
        for(key,value) in dictionary
        {
            if(value == color)
            {
                return key
            }
        }
        return 0
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        numOfRaindropsTF.text = String(rainVC.numberOfRaindrops)
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    
    //function for displaying popup
    func displayAlertControllerWithTitle(title:String, message:String) {
        let uiAlertController:UIAlertController = UIAlertController(title: title,
            message: message, preferredStyle: UIAlertControllerStyle.Alert)
        uiAlertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel,
            handler:{(action:UIAlertAction)->Void in  }))
        self.presentViewController(uiAlertController, animated: true, completion: nil)
    }
    
    
}
