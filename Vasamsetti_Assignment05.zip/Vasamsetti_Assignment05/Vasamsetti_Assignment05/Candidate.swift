//
//  Candidate.swift
//  Vasamsetti_Assignment05
//
//  Created by chandrasekhar vasamsetti on 2/21/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import Foundation
import UIKit

class Candidate {
    
    var image:String
    var name:String
    var noOfVotes:Double
    
    init(image:String, name:String, noOfVotes:Double) {
        
        self.image = image
        self.name = name
        self.noOfVotes = noOfVotes
        
    }
       
    
}