//
//  ViewController.swift
//  Vasamsetti_Assignment05
//
//  Created by chandrasekhar vasamsetti on 2/26/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {

    @IBOutlet var candidateTableView: UITableView!
    
    
    
    override func viewDidLoad() {
     // calls type method in Pollfactory class
        PollFactory.createModel()
        //self.tableView.
        
    }
    
    // returns the numbers of sections in the table view
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return PollFactory.parties.count
    }
    
    // returns the title for header in section
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return PollFactory.parties[section].partyName
    }
    
    // returns the number of rows in section
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return PollFactory.parties[section].dictionary.keys.count
    }
    
    // display the content for cell in a table
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
    
        let cell:UITableViewCell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath)
        tableView.rowHeight = 108
        let nameLBL:UILabel = cell.viewWithTag(101) as! UILabel
        let votePrecentLBL:UILabel = cell.viewWithTag(102) as! UILabel
        let profilePicIV:UIImageView = cell.viewWithTag(100) as! UIImageView
        nameLBL.text = PollFactory.parties[indexPath.section].displayOrder()[indexPath.row].name
        votePrecentLBL.text = "\(round(100 * PollFactory.parties[indexPath.section].getPercentage(PollFactory.parties[indexPath.section].displayOrder()[indexPath.row].name)) / 100)"
        
        profilePicIV.image = UIImage(named: PollFactory.parties[indexPath.section].displayOrder()[indexPath.row].image)
        
        return cell
        
    }
    
    // calls when user tapps on the cell of a table
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
       
        PollFactory.parties[indexPath.section].updateVote(PollFactory.parties[indexPath.section].displayOrder()[indexPath.row].name)
       
        PollFactory.parties[indexPath.section].getPercentage(PollFactory.parties[indexPath.section].displayOrder()[indexPath.row].name)
        PollFactory.parties[indexPath.section].displayOrder()
        self.tableView.reloadData()
    }
    
}

