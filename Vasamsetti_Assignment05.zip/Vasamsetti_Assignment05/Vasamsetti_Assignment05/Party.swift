//
//  Party.swift
//  Vasamsetti_Assignment05
//
//  Created by chandrasekhar vasamsetti on 2/21/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import Foundation
import UIKit


class Party {
    
    var partyName:String
    var dictionary:[String:Candidate]
    
   // calls when party object is created
    init(partyName:String, dictionary:[String:Candidate]){
        self.partyName = partyName
        self.dictionary = dictionary
    }
    
    // returns array in descending order
    func displayOrder() -> Array<Candidate>{
        var array:Array<Candidate> = []
        for (_, cand) in dictionary{
            array.append(cand)
        }
        array.sortInPlace({$0.noOfVotes > $1.noOfVotes})
        return array
    }
    
    func getPercentage( name:String) -> Double{
        var allVotes = 0.0
        for i in dictionary.values{
            allVotes = allVotes + i.noOfVotes
        }
        if allVotes == 0{
            return 0
        }
        else{
            return 100.0 * dictionary[name]!.noOfVotes / (allVotes)
        }
    }
    
    func updateVote(name:String){
        dictionary[name]!.noOfVotes += 1
    }
    
    func addCandidate(candidate:Candidate){
        dictionary[candidate.name] = candidate
        
    }
    
}