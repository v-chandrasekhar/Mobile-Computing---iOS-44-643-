//
//  PollFactory.swift
//  Vasamsetti_Assignment05
//
//  Created by chandrasekhar vasamsetti on 2/26/16.
//  Copyright © 2016 chandrasekhar vasamsetti. All rights reserved.
//

import Foundation

// To create candidate objects and assign them to party group
class PollFactory {
    
    // static variable 'parties' to store Party class objects
    static var parties:[Party]!
    
    // createModel type method
    class func createModel(){
        // instantiate Candidate objects
        let c1 = Candidate(image: "clinton-2016.jpg", name: "Hilary", noOfVotes: 0)
        let c2 = Candidate(image: "berniesanders.jpg", name: "Sanders", noOfVotes: 0)
        let c3 = Candidate(image: "trump.jpg", name: "trump", noOfVotes: 0)
        let c4 = Candidate(image: "TedCruz.jpg", name: "Cruz", noOfVotes: 0)
        let c5 = Candidate(image: "MarcoRubio.jpg", name: "Rubio", noOfVotes: 0)
        
        // instantiate party objects
        let p1 = Party(partyName: "Democrate", dictionary: ["Hilary" : c1, "Sanders" : c2] )
        let p2 = Party(partyName: "Republican", dictionary: ["trump" : c3, "Cruz":c4])
        p2.addCandidate(c5)
        
        parties = [p1,p2]
    }

    
    
}